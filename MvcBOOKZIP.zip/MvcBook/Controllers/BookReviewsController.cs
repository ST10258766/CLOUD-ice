﻿using Microsoft.AspNetCore.Mvc;
using MvcBook.Data;
using MvcBook.Models;

namespace MvcBook.Controllers
{
    public class BookReviewsController : Controller
    {
        private readonly MvcBookContext _context;

        public BookReviewsController(MvcBookContext context)
        {
            _context = context;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BookReview review)
        {
            if (ModelState.IsValid)
            {
                _context.Add(review);
                await _context.SaveChangesAsync();
                return RedirectToAction("Details", "Books", new { id = review.BookId });
            }
            return RedirectToAction("Details", "Books", new { id = review.BookId }); // Handle validation errors
        }
    }
}

