﻿using Microsoft.EntityFrameworkCore;
using MvcBook.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcBook.Data;
using System;
using System.Linq;

namespace MvcBook.Models
{
    // SeedData class within the same namespace
    public static class SeedData
    {

        public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new MvcBookContext(
            serviceProvider.GetRequiredService<DbContextOptions<MvcBookContext>>()))
        {
            // Look for any books.
            if (context.Books.Any())
            {
                return;   // DB has been seeded
            }

            context.Books.AddRange(
                new Book
                {
                    Title = "The Great Gatsby",
                    Author = "F. Scott Fitzgerald",
                    ReleaseDate = DateTime.Parse("1925-4-10"),
                    Genre = "Novel",
                    Price = 10.99M
                },
                new Book
                {
                    Title = "To Kill a Mockingbird",
                    Author = "Harper Lee",
                    ReleaseDate = DateTime.Parse("1960-7-11"),
                    Genre = "Novel",
                    Price = 7.99M
                },
                new Book
                {
                    Title = "1984",
                    Author = "George Orwell",
                    ReleaseDate = DateTime.Parse("1949-6-8"),
                    Genre = "Dystopian",
                    Price = 8.99M
                },
                new Book
                {
                    Title = "Moby-Dick",
                    Author = "Herman Melville",
                    ReleaseDate = DateTime.Parse("1851-11-14"),
                    Genre = "Adventure",
                    Price = 9.99M
                }
            );

            context.SaveChanges();
        }
    }
}
}